﻿using System;
using System.Collections.Generic;

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;

/// <summary>
/// Class for ExternalEventHandler, that does most of the interactions with Revit.
/// </summary>

namespace IDParameterLevel6
{
    public class RequestHandler : IExternalEventHandler
    {
        private Request request = new Request();
        static UIApplication uiapp = null;
        static Document doc = null;
        public static List<Element> selectedElements = new List<Element>();
        public static List<Reference> preSelectedElements = new List<Reference>();

        public Request Request
        {
            get { return request; }
        }

        public String GetName() //this method returns the name of the Handler.
        {
            return "CAD Studio Test";
        }
        //Main method of this class
        public void Execute(UIApplication uiapplication)
        {
            uiapp = uiapplication;
            doc = uiapplication.ActiveUIDocument.Document;
            try
            {
                switch (Request.Take()) //switch that calls on functions, depending on what was clicked in SelectionWindow.
                {
                    case RequestId.None: // Default value of Request.
                        {
                            return;  
                        }
                    case RequestId.All: //User clicked on the Confirm button and radioButton_SelectAll was checked.
                        {
                            GetAllElementsInCanvas();
                            WriteElementID(selectedElements);
                            Application.thisApp.CloseWindow();
                            break;
                            
                        }
                    case RequestId.UserSelected: //User clicked on the Confirm button and radioButton_UserSelect was checked.
                        {
                            if (SelectionWindow.userClickedSelectButton) {
                                if (selectedElements.Count >= 1)
                                    WriteElementID(selectedElements);
                            }
                            else
                            {
                                GetPreSelectedElements();
                                if (selectedElements.Count >= 1)
                                    WriteElementID(selectedElements);
                            }
                            Application.thisApp.CloseWindow();
                            break;
                            
                        }
                    case RequestId.Selection: //User clicked on the Select button.
                        {
                            UserSelection();
                            Application.thisApp.SetFocusOnWindow();
                            break;
                        }
                    default:
                        {
                            break;
                        }
                }
            }
            finally
            {
                Application.thisApp.WakeWindowUp();
            }

            return;
        }

        private void WriteElementID(List<Element> elements) //Method for writing ElementID to parameter named ID for selected Objects in Revit.
        {
            foreach (Element e in elements)
            {
                try
                {
                    Parameter para = e.LookupParameter("ID");
                    if (para != null)
                    {
                        using (Transaction t = new Transaction(doc, "Setting the ID parameter"))
                        {
                            t.Start();
                            para.Set(e.Id.ToString());
                            t.Commit();
                        }
                    }

                }
                catch (Exception ex)
                {
                    TaskDialog.Show("Error", ex.Message);
                }
            }
            preSelectedElements.Clear();
            selectedElements.Clear();
        }
        public void GetAllElementsInCanvas() //Method for retrieving all visible Objects in Revit.
        {
            FilteredElementCollector collector = new FilteredElementCollector(doc).WhereElementIsNotElementType();
            foreach (Element e in collector)
            {
                if (null != e.Category && e.Category.HasMaterialQuantities)
                {
                    selectedElements.Add(e);
                }
            }
        }

        public static void UserSelection() //Method for retrieving Objects, that were selected by User.
        {
            SelectionFilter filter = new SelectionFilter();
            GetPreSelectedElements();
            IList<Reference> elementsSel = uiapp.ActiveUIDocument.Selection.PickObjects(ObjectType.Element, filter, "Select objects", preSelectedElements);
            foreach (Reference r in elementsSel)
            {
                selectedElements.Add(doc.GetElement(r.ElementId));
            }
            SelectionWindow.userClickedSelectButton = false;
        }

        public static void GetPreSelectedElements() //Method for retrieving Objects, that were selected preselected in Revit.
        {
            List<ElementId> selElementID = (List<ElementId>)uiapp.ActiveUIDocument.Selection.GetElementIds();
            Reference r;
            foreach(ElementId eid in selElementID)
            {
                r = new Reference(doc.GetElement(eid));
                preSelectedElements.Add(r);
                if (!SelectionWindow.userClickedSelectButton) //Happens is User hadn´t used the Select button and wants to write the ID of preselected Object only. 
                    selectedElements.Add(doc.GetElement(eid));
            }
        }
            
        
    }  

}  
