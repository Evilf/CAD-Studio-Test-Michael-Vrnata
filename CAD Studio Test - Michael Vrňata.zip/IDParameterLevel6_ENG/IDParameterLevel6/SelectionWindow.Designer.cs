﻿
namespace IDParameterLevel6
{
    partial class SelectionWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_Confirm = new System.Windows.Forms.Button();
            this.button_Cancel = new System.Windows.Forms.Button();
            this.radio_Buttons = new System.Windows.Forms.GroupBox();
            this.button_Select = new System.Windows.Forms.Button();
            this.radioButton_UserSelect = new System.Windows.Forms.RadioButton();
            this.radioButton_SelectAll = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.radio_Buttons.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_Confirm
            // 
            this.button_Confirm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Confirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.button_Confirm.Location = new System.Drawing.Point(252, 134);
            this.button_Confirm.Name = "button_Confirm";
            this.button_Confirm.Size = new System.Drawing.Size(89, 31);
            this.button_Confirm.TabIndex = 0;
            this.button_Confirm.Text = "Confirm";
            this.button_Confirm.UseVisualStyleBackColor = true;
            this.button_Confirm.Click += new System.EventHandler(this.button_Confirm_Click);
            // 
            // button_Cancel
            // 
            this.button_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button_Cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.button_Cancel.Location = new System.Drawing.Point(347, 134);
            this.button_Cancel.Name = "button_Cancel";
            this.button_Cancel.Size = new System.Drawing.Size(57, 31);
            this.button_Cancel.TabIndex = 1;
            this.button_Cancel.Text = "Cancel";
            this.button_Cancel.UseVisualStyleBackColor = true;
            this.button_Cancel.Click += new System.EventHandler(this.button_Cancel_Click);
            // 
            // radio_Buttons
            // 
            this.radio_Buttons.Controls.Add(this.button_Select);
            this.radio_Buttons.Controls.Add(this.radioButton_UserSelect);
            this.radio_Buttons.Controls.Add(this.radioButton_SelectAll);
            this.radio_Buttons.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.radio_Buttons.Location = new System.Drawing.Point(16, 41);
            this.radio_Buttons.Name = "radio_Buttons";
            this.radio_Buttons.Size = new System.Drawing.Size(397, 87);
            this.radio_Buttons.TabIndex = 2;
            this.radio_Buttons.TabStop = false;
            this.radio_Buttons.Text = "Pick objects";
            // 
            // button_Select
            // 
            this.button_Select.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Select.Enabled = false;
            this.button_Select.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.button_Select.Location = new System.Drawing.Point(308, 52);
            this.button_Select.Name = "button_Select";
            this.button_Select.Size = new System.Drawing.Size(89, 31);
            this.button_Select.TabIndex = 4;
            this.button_Select.Text = "Select";
            this.button_Select.UseVisualStyleBackColor = true;
            this.button_Select.Click += new System.EventHandler(this.button_Select_Click);
            // 
            // radioButton_UserSelect
            // 
            this.radioButton_UserSelect.AutoSize = true;
            this.radioButton_UserSelect.Location = new System.Drawing.Point(6, 55);
            this.radioButton_UserSelect.Name = "radioButton_UserSelect";
            this.radioButton_UserSelect.Size = new System.Drawing.Size(299, 24);
            this.radioButton_UserSelect.TabIndex = 1;
            this.radioButton_UserSelect.TabStop = true;
            this.radioButton_UserSelect.Text = "Only selected objects in current project";
            this.radioButton_UserSelect.UseVisualStyleBackColor = true;
            this.radioButton_UserSelect.CheckedChanged += new System.EventHandler(this.radioButton_UserSelect_CheckedChanged);
            // 
            // radioButton_SelectAll
            // 
            this.radioButton_SelectAll.AutoSize = true;
            this.radioButton_SelectAll.Checked = true;
            this.radioButton_SelectAll.Location = new System.Drawing.Point(6, 25);
            this.radioButton_SelectAll.Name = "radioButton_SelectAll";
            this.radioButton_SelectAll.Size = new System.Drawing.Size(221, 24);
            this.radioButton_SelectAll.TabIndex = 0;
            this.radioButton_SelectAll.TabStop = true;
            this.radioButton_SelectAll.Text = "All objects in current project";
            this.radioButton_SelectAll.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(217, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Writes ID for selected objects";
            // 
            // SelectionWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(416, 180);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.radio_Buttons);
            this.Controls.Add(this.button_Cancel);
            this.Controls.Add(this.button_Confirm);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SelectionWindow";
            this.ShowIcon = false;
            this.Text = "ElementIDProperty";
            this.radio_Buttons.ResumeLayout(false);
            this.radio_Buttons.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_Confirm;
        private System.Windows.Forms.Button button_Cancel;
        private System.Windows.Forms.GroupBox radio_Buttons;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButton_UserSelect;
        private System.Windows.Forms.RadioButton radioButton_SelectAll;
        private System.Windows.Forms.Button button_Select;
    }
}