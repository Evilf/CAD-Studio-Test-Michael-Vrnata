﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System.Windows.Media.Imaging;
using Autodesk.Revit.Attributes;

/// <summary>
/// Class for IExternalApplication, that adds new panel and button in Revit.
/// </summary>

namespace IDParameterLevel6
{
    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]
    public class Application : IExternalApplication
    {
        internal static Application thisApp = null;
        private SelectionWindow window;

        public Result OnShutdown(UIControlledApplication application) //Runs when the addin is closed.
        {
            return Result.Succeeded;
        }

        public Result OnStartup(UIControlledApplication application) //Runs when the addin is loaded.
        {
            AddRibbonPanelAndButton(application);
            thisApp = this;

            return Result.Succeeded;
        }

        static void AddRibbonPanelAndButton(UIControlledApplication application) //Method for adding new panel and button in Revit.
        {
            String tabName = "CAD Studio Test";
            string thisAssemblyPath = Assembly.GetExecutingAssembly().Location;
            BitmapImage buttonIcon = new BitmapImage(new Uri(Environment.CurrentDirectory + "/button_Icon.png"));

            application.CreateRibbonTab(tabName);
            RibbonPanel ribbonPanel = application.CreateRibbonPanel(tabName, "Tools");

            PushButtonData buttonData = new PushButtonData("ElementID_Button","Write\r\nID" ,thisAssemblyPath, "IDParameterLevel6.RevitButtonClick");
            PushButton button = ribbonPanel.AddItem(buttonData) as PushButton;
            button.ToolTip = "Opens Element ID selection window";
            button.LargeImage = buttonIcon;
        }

        public void ShowWindow(UIApplication uiapp) //Method for Displaying SelectionWindow.
        {
            if (window == null || window.IsDisposed)
            {
                RequestHandler handler = new RequestHandler();

                ExternalEvent exEvent = ExternalEvent.Create(handler);

                window = new SelectionWindow(uiapp.ActiveUIDocument, exEvent, handler);
                window.Show();
            }
            else
                SetFocusOnWindow();
        }
        public void WakeWindowUp() //Method for Unlocking SelectionWindow controls.
        {
            if (window != null)
            {
                window.WakeUp();
            }
        }

        public void CloseWindow() //Method for Closing SelectionWindow.
        {
            window.Close();
        }

        public void SetFocusOnWindow() //Method for setting focus on SelectionWindow.
        {
            window.Focus();
        }
    }
}
