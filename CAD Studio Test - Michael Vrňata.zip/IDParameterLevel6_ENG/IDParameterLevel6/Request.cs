﻿using System;
using System.Threading;

/// <summary>
/// Class for RequestId variable, that is safe for use in multi-threading.
/// </summary>

namespace IDParameterLevel6
{
   public enum RequestId : int
   {
       None = 0,
       All = 1,
       UserSelected = 2,
       Selection = 3
   }

   public class Request
   {
      private int m_reguest = (int)RequestId.None;
      public RequestId Take()
      {
         return (RequestId)Interlocked.Exchange(ref m_reguest, (int)RequestId.None);
      }
      public void Make(RequestId request)
      {
         Interlocked.Exchange(ref m_reguest, (int)request);
      }
   }
}
