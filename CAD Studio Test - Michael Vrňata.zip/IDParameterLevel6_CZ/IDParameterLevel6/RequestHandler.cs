﻿using System;
using System.Collections.Generic;

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;

/// <summary>
/// Třída pro ExternalEventHandler, která provádí většinu interakcí s programem Revit.
/// </summary>

namespace IDParameterLevel6
{
    public class RequestHandler : IExternalEventHandler
    {
        private Request request = new Request();
        static UIApplication uiapp = null;
        static Document doc = null;
        public static List<Element> selectedElements = new List<Element>();
        public static List<Reference> preSelectedElements = new List<Reference>();

        public Request Request
        {
            get { return request; }
        }

        public String GetName() //Tato metoda vrací název Handleru.
        {
            return "CAD Studio Test";
        }
        //Hlavní metoda této třídy.
        public void Execute(UIApplication uiapplication)
        {
            uiapp = uiapplication;
            doc = uiapplication.ActiveUIDocument.Document;
            try
            {
                switch (Request.Take()) //Switch, ktarý volá metody podle toho na co uživatel klikl v SelectionWindow.
                {
                    case RequestId.None: //Výchozí hodnota požadavku.
                        {
                            return;  
                        }
                    case RequestId.All: //Uživatel klikl na tlačítko Potvrdit a radioButton_SelectAll bylo zaškrtnuto.
                        {
                            GetAllElementsInCanvas();
                            WriteElementID(selectedElements);
                            Application.thisApp.CloseWindow();
                            break;
                            
                        }
                    case RequestId.UserSelected: //Uživatel klikl na tlačítko Potvrdit a radioButton_UserSelect bylo zaškrtnuto.
                        {
                            if (SelectionWindow.userClickedSelectButton) {
                                if (selectedElements.Count >= 1)
                                    WriteElementID(selectedElements);
                            }
                            else
                            {
                                GetPreSelectedElements();
                                if (selectedElements.Count >= 1)
                                    WriteElementID(selectedElements);
                            }
                            Application.thisApp.CloseWindow();
                            break;
                            
                        }
                    case RequestId.Selection: //Uživatel klikl na tlačítko Výběr z projektu.
                        {
                            UserSelection();
                            Application.thisApp.SetFocusOnWindow();
                            break;
                        }
                    default:
                        {
                            break;
                        }
                }
            }
            finally
            {
                Application.thisApp.WakeWindowUp();
            }

            return;
        }

        private void WriteElementID(List<Element> elements) //Metoda pro zápis ElementID do parametru s názvem ID pro vybrané objekty v aplikaci Revit.
        {
            foreach (Element e in elements)
            {
                try
                {
                    Parameter para = e.LookupParameter("ID");
                    if (para != null)
                    {
                        using (Transaction t = new Transaction(doc, "Setting the ID parameter"))
                        {
                            t.Start();
                            para.Set(e.Id.ToString());
                            t.Commit();
                        }
                    }

                }
                catch (Exception ex)
                {
                    TaskDialog.Show("Error", ex.Message);
                }
            }
            preSelectedElements.Clear();
            selectedElements.Clear();
        }
        public void GetAllElementsInCanvas() //Metoda načítání všech viditelných objektů v aplikaci Revit.
        {
            FilteredElementCollector collector = new FilteredElementCollector(doc).WhereElementIsNotElementType();
            foreach (Element e in collector)
            {
                if (null != e.Category && e.Category.HasMaterialQuantities)
                {
                    selectedElements.Add(e);
                }
            }
        }

        public static void UserSelection() //Metoda načítání objektů, které byly vybrány uživatelem.
        {
            SelectionFilter filter = new SelectionFilter();
            GetPreSelectedElements();
            IList<Reference> elementsSel = uiapp.ActiveUIDocument.Selection.PickObjects(ObjectType.Element, filter, "Select objects", preSelectedElements);
            foreach (Reference r in elementsSel)
            {
                selectedElements.Add(doc.GetElement(r.ElementId));
            }
            SelectionWindow.userClickedSelectButton = false;
        }

        public static void GetPreSelectedElements() //Metoda načítání objektů, které byly předvoleny v aplikaci Revit.
        {
            List<ElementId> selElementID = (List<ElementId>)uiapp.ActiveUIDocument.Selection.GetElementIds();
            Reference r;
            foreach(ElementId eid in selElementID)
            {
                r = new Reference(doc.GetElement(eid));
                preSelectedElements.Add(r);
                if (!SelectionWindow.userClickedSelectButton) //Provede se, pokud uživatel nepoužil tlačítko Výběr z projektu a chce zapsat pouze ID předvolených objektů. 
                    selectedElements.Add(doc.GetElement(eid));
            }
        }
            
        
    }  

}  
