﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System.Windows.Media.Imaging;
using Autodesk.Revit.Attributes;

/// <summary>
/// Třída pro IExternalApplication, která přidává nový panel a tlačítko v aplikaci Revit.
/// </summary>

namespace IDParameterLevel6
{
    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]
    public class Application : IExternalApplication
    {
        internal static Application thisApp = null;
        private SelectionWindow window;

        public Result OnShutdown(UIControlledApplication application) //Spustí se před vypnutím add-inu.
        {
            return Result.Succeeded;
        }

        public Result OnStartup(UIControlledApplication application) //Spustí se při startu add-inu.
        {
            AddRibbonPanelAndButton(application);
            thisApp = this;

            return Result.Succeeded;
        }

        static void AddRibbonPanelAndButton(UIControlledApplication application) //Metoda pro přidání nového panelu a tlačítka v aplikaci Revit.
        {
            String tabName = "CAD Studio Test";
            string thisAssemblyPath = Assembly.GetExecutingAssembly().Location;
            BitmapImage buttonIcon = new BitmapImage(new Uri(Environment.CurrentDirectory + "/button_Icon.png"));

            application.CreateRibbonTab(tabName);
            RibbonPanel ribbonPanel = application.CreateRibbonPanel(tabName, "Tools");

            PushButtonData buttonData = new PushButtonData("ElementID_Button","Write\r\nID" ,thisAssemblyPath, "IDParameterLevel6.RevitButtonClick");
            PushButton button = ribbonPanel.AddItem(buttonData) as PushButton;
            button.ToolTip = "Opens Element ID selection window";
            button.LargeImage = buttonIcon;
        }

        public void ShowWindow(UIApplication uiapp) //Metoda pro zobrazení SelectionWindow.
        {
            if (window == null || window.IsDisposed)
            {
                RequestHandler handler = new RequestHandler();

                ExternalEvent exEvent = ExternalEvent.Create(handler);

                window = new SelectionWindow(uiapp.ActiveUIDocument, exEvent, handler);
                window.Show();
            }
            else
                SetFocusOnWindow();
        }
        public void WakeWindowUp() //Metoda pro odemčení SelectionWindow controls.
        {
            if (window != null)
            {
                window.WakeUp();
            }
        }

        public void CloseWindow() //Metoda pro zavření SelectionWindow.
        {
            window.Close();
        }

        public void SetFocusOnWindow() //Metoda pro umístění okna SelectionWindow do popředí.
        {
            window.Focus();
        }
    }
}
