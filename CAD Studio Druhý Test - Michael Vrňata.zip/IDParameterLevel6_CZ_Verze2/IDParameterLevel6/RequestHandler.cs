﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;

/// <summary>
/// Třída pro ExternalEventHandler, která provádí většinu interakcí s programem Revit.
/// </summary>

namespace IDParameterLevel6
{
    public class RequestHandler : IExternalEventHandler
    {
        bool hasAlteredParameter = false;
        RequestId clickedButton;
        private Request request = new Request();
        static UIApplication uiapp = null;
        static Document doc = null;
        public static List<Element> selectedElements = new List<Element>();
        public static List<Reference> preSelectedElements = new List<Reference>();

        public Request Request
        {
            get { return request; }
        }

        public String GetName() //Tato metoda vrací název Handleru.
        {
            return "CAD Studio Test";
        }
        //Hlavní metoda této třídy.
        public void Execute(UIApplication uiapplication)
        {
            uiapp = uiapplication;
            doc = uiapplication.ActiveUIDocument.Document;
            try
            {
                clickedButton = Request.Take();
                switch (clickedButton) //Switch, ktarý volá metody podle toho na co uživatel klikl v SelectionWindow.
                {
                    case RequestId.None: //Výchozí hodnota požadavku.
                        {
                            return;  
                        }
                    case RequestId.All: //Uživatel klikl na tlačítko Potvrdit a radioButton_SelectAll bylo zaškrtnuto.
                        {
                            GetAllElementsInCanvas();
                            WriteElementID(selectedElements);
                            Application.thisApp.CloseWindow();
                            break;
                            
                        }
                    case RequestId.UserSelected: //Uživatel klikl na tlačítko Potvrdit a radioButton_UserSelect bylo zaškrtnuto.
                        {
                            if (SelectionWindow.userClickedSelectButton) {
                                if (selectedElements.Count >= 1)
                                    WriteElementID(selectedElements);
                            }
                            else
                            {
                                GetPreSelectedElements();
                                if (selectedElements.Count >= 1)
                                    WriteElementID(selectedElements);
                            }
                            Application.thisApp.CloseWindow();
                            break;
                            
                        }
                    case RequestId.Selection: //Uživatel klikl na tlačítko Výběr z projektu.
                        {
                            UserSelection();
                            Application.thisApp.SetFocusOnWindow();
                            break;
                        }
                    default:
                        {
                            break;
                        }
                }
            }
            finally
            {
                Application.thisApp.WakeWindowUp();
            }

            return;
        }

        #region Výběr objektů a zápis do jejich parametru ID

        private void WriteElementID(List<Element> elements) //Metoda pro zápis ElementID do parametru s názvem ID pro vybrané objekty v aplikaci Revit.
        {
            foreach (Element e in elements)
            {
                try
                {
                Restart:
                    Parameter para = e.LookupParameter("ID");
                    if (para != null)
                    {
                        using (Transaction t = new Transaction(doc, "Zápis ID do parameteru"))
                        {
                            t.Start();
                            para.Set(e.Id.ToString());
                            t.Commit();
                            t.Dispose();
                        }
                    }
                    else
                    {
                        if (!hasAlteredParameter) {
                            CheckForIDParameter();
                            goto Restart;
                        }
                    }

                }
                catch (Exception ex)
                {
                    TaskDialog.Show("Error", ex.Message);
                }
            }

            hasAlteredParameter = false;
            preSelectedElements.Clear();
            selectedElements.Clear();
        }
        public void GetAllElementsInCanvas() //Metoda načítání všech viditelných objektů v aplikaci Revit.
        {
            FilteredElementCollector collector = new FilteredElementCollector(doc).WhereElementIsNotElementType();
            foreach (Element e in collector)
            {
                if (null != e.Category && (e.Category.HasMaterialQuantities || e.Category.AllowsBoundParameters))
                {
                    selectedElements.Add(e);
                }
            }
        }

        public static void UserSelection() //Metoda načítání objektů, které byly vybrány uživatelem.
        {
            SelectionFilter filter = new SelectionFilter();
            GetPreSelectedElements();
            IList<Reference> elementsSel = uiapp.ActiveUIDocument.Selection.PickObjects(ObjectType.Element, filter, "Vyberte objekty", preSelectedElements);
            foreach (Reference r in elementsSel)
            {
                selectedElements.Add(doc.GetElement(r.ElementId));
            }
            SelectionWindow.userClickedSelectButton = false;
        }

        public static void GetPreSelectedElements() //Metoda načítání objektů, které byly předvoleny v aplikaci Revit.
        {
            List<ElementId> selElementID = (List<ElementId>)uiapp.ActiveUIDocument.Selection.GetElementIds();
            Reference r;
            foreach(ElementId eid in selElementID)
            {
                r = new Reference(doc.GetElement(eid));
                preSelectedElements.Add(r);
                if (!SelectionWindow.userClickedSelectButton) //Provede se, pokud uživatel nepoužil tlačítko Výběr z projektu a chce zapsat pouze ID předvolených objektů. 
                    selectedElements.Add(doc.GetElement(eid));
            }
        }

        #endregion

        #region Tvorba/úprava parametru ID

        public void CheckForIDParameter() //Metoda pro kontrolu parametru ID.
        {
            try
            {
                bool paraIDExists = false;
                Definition paraDef = null;
                ElementBinding eBinding = null;
                BindingMap map = doc.ParameterBindings;
                DefinitionBindingMapIterator it = map.ForwardIterator();
                it.Reset();
                while (it.MoveNext()) //Kontrola zda již existuje parametr ID.
                {
                    ElementBinding eleBinding = it.Current as ElementBinding;
                    Definition def = it.Key;
                    if (def != null)
                    {
                        if (def.Name == "ID")
                        {
                            paraDef = def;
                            paraIDExists = true;
                            eBinding = eleBinding;
                        }
                    }
                }
                if (!paraIDExists) //Provede se pouze pokud parametr ID neexistuje.
                {
                    using (Transaction trans = new Transaction(doc, "Vytvořit project parameter ID"))
                    {
                        trans.Start();
                        CategorySet cats;
                        if (clickedButton == RequestId.All)
                        {
                            cats = GetCategorySetFromVisibleElementsInProject();
                        }
                        else
                        {
                            cats = GetCategorySetFromSelectedElementsInProject(eBinding);
                        }
                        RawCreateProjectParameter("ID", ParameterType.Text, true, cats, BuiltInParameterGroup.PG_DATA, true);
                        trans.Commit();
                    }
                }
                else //Provede se pokud parametr ID existuje, ale nemá požadovanou kategorii objektu.
                {
                    using (Transaction trans = new Transaction(doc, "Upravit project parameter ID"))
                    {
                        trans.Start();
                        CategorySet cats;
                        if (clickedButton == RequestId.All)
                        {
                            cats = GetCategorySetFromVisibleElementsInProject();
                        }
                        else
                        {
                            cats = GetCategorySetFromSelectedElementsInProject(eBinding);
                        }
                        Binding binding = uiapp.Application.Create.NewInstanceBinding(cats);
                        map.ReInsert(paraDef, binding, BuiltInParameterGroup.PG_DATA);
                        trans.Commit();
                    }
                }
                hasAlteredParameter = true;
            }
            catch (Exception ex)
            {
                TaskDialog.Show("Error", ex.Message);
            }
        }

        public static void RawCreateProjectParameter(string name, ParameterType type, bool visible, CategorySet cats, BuiltInParameterGroup group, bool inst) //Metoda pro vytvoření nového parametru ID.
        {
            string oriFile = uiapp.Application.SharedParametersFilename;
            string tempFile = Path.GetTempFileName() + ".txt";
            using (File.Create(tempFile)) { }
            uiapp.Application.SharedParametersFilename = tempFile;

            var defOptions = new ExternalDefinitionCreationOptions(name, type)
            {
                Visible = visible
            };
            ExternalDefinition def = uiapp.Application.OpenSharedParameterFile().Groups.Create("TemporaryDefintionGroup").Definitions.Create(defOptions) as ExternalDefinition;

            uiapp.Application.SharedParametersFilename = oriFile;
            File.Delete(tempFile);

            Binding binding = uiapp.Application.Create.NewTypeBinding(cats);
            if (inst) binding = uiapp.Application.Create.NewInstanceBinding(cats);

            BindingMap map = doc.ParameterBindings;
            map.Insert(def, binding, group);
            
        }

        public CategorySet GetCategorySetFromVisibleElementsInProject() //Získá kategorie všech objektů v projektu, které mohou mít parametr ID.
        {
            CategorySet catSet = new CategorySet();
            FilteredElementCollector collector = new FilteredElementCollector(doc).WhereElementIsNotElementType();
            foreach(Element e in collector)
            {
                if (null != e.Category && (e.Category.HasMaterialQuantities || e.Category.AllowsBoundParameters))
                {
                    if (!catSet.Contains(e.Category))
                    {
                        catSet.Insert(e.Category);
                    }
                }
            }

            return catSet;
        }

        public CategorySet GetCategorySetFromSelectedElementsInProject(ElementBinding eBinding) //Získá kategorie z vybraných objektů.
        {
            CategorySet catSet = new CategorySet();
            if (eBinding != null) //Pokud již existuje ID parametr, přídá jeho kategorie do kategorií vybraných objektů.
            {
                foreach (Category cat in eBinding.Categories)
                {
                    catSet.Insert(cat);
                }
            }

            foreach (Element e in selectedElements)
            {
                if (null != e.Category && (e.Category.HasMaterialQuantities || e.Category.AllowsBoundParameters))
                {
                    if (!catSet.Contains(e.Category))
                    {
                        catSet.Insert(e.Category);
                    }
                }
            }

            return catSet;
        }
        #endregion
    }

}  
