﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

/// <summary>
/// Třída pro formulář SelectionWindow a jeho komponenty.
/// </summary>

namespace IDParameterLevel6
{
    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]

    public partial class SelectionWindow : System.Windows.Forms.Form
    {
        public static bool userClickedSelectButton = false;
        public string radioButton_Selected = null;
        private RequestHandler m_Handler;
        private ExternalEvent m_ExEvent;
        private UIDocument uIDoc = null;

        public SelectionWindow(UIDocument uIDocument,ExternalEvent exEvent, RequestHandler handler) //Konstruktor třídy
        {
            InitializeComponent();
            m_Handler = handler;
            m_ExEvent = exEvent;
            uIDoc = uIDocument;
        }

        protected override void OnFormClosed(FormClosedEventArgs e) //Metoda pro likvidaci ExternalEventu při zavření SelectionWindow.
        {
            m_ExEvent.Dispose();
            m_ExEvent = null;
            m_Handler = null;
            base.OnFormClosed(e);
        }

        private void EnableCommands(bool status) //Metoda pro odemknutí/uzamknutí ovládacích prvků SelectionWindow.
        {
            foreach (System.Windows.Forms.Control ctrl in this.Controls)
            {
                ctrl.Enabled = status;
            }
            if (!status)
            {
                button_Cancel.Enabled = true;
            }
        }

        private void MakeRequest(RequestId request) //Metoda pro vytváření požadavků a zamykání ovládacích prvků SelectionWindow.

        {
            m_Handler.Request.Make(request);
            m_ExEvent.Raise();
            DozeOff();
        }

        private void DozeOff() //Metoda pro zamykání ovládacích prvků SelectionWindow.

        {
            EnableCommands(false);
        }

        public void WakeUp() //Metoda pro odemykání ovládacích prvků SelectionWindow.
        {
            EnableCommands(true);
        }

        private void button_Confirm_Click(object sender, EventArgs e) //Metoda pro Event kliknutí na tlačítko Potvrdit.
        {
            if (radioButton_SelectAll.Checked)
                MakeRequest(RequestId.All);
            else if (radioButton_UserSelect.Checked)
                MakeRequest(RequestId.UserSelected);
            else
                radioButton_Selected = null;
        }

        private void button_Cancel_Click(object sender, EventArgs e) //Metoda pro Event kliknutí na tlačítko Zrušit.
        {
            this.Close();
        }

        private void button_Select_Click(object sender, EventArgs e) //Metoda pro Event kliknutí na tlačítko Výběr z projektu.
        {
            userClickedSelectButton = true;
            MakeRequest(RequestId.Selection);
        }

        private void radioButton_UserSelect_CheckedChanged(object sender, EventArgs e) //Metoda pro odemčení/uzamčení tlačítka Výběr z projektu.
        {
            if (radioButton_UserSelect.Checked == true)
                button_Select.Enabled = true;
            else
                button_Select.Enabled = false;
        }
    }
}
