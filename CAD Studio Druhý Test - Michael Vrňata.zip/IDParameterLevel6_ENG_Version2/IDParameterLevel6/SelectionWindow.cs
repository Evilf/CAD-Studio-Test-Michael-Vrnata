﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

/// <summary>
/// Class for SelectionWindow Form and its components.
/// </summary>

namespace IDParameterLevel6
{
    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]

    public partial class SelectionWindow : System.Windows.Forms.Form
    {
        public static bool userClickedSelectButton = false;
        public string radioButton_Selected = null;
        private RequestHandler m_Handler;
        private ExternalEvent m_ExEvent;
        private UIDocument uIDoc = null;

        public SelectionWindow(UIDocument uIDocument,ExternalEvent exEvent, RequestHandler handler) //Class Constructor
        {
            InitializeComponent();
            m_Handler = handler;
            m_ExEvent = exEvent;
            uIDoc = uIDocument;
        }

        protected override void OnFormClosed(FormClosedEventArgs e) //Method for disposing of the ExternalEvent when the SelectionWindow is closed.
        {
            m_ExEvent.Dispose();
            m_ExEvent = null;
            m_Handler = null;
            base.OnFormClosed(e);
        }

        private void EnableCommands(bool status) //Method for Unlocking/Locking SelectionWindow controls.
        {
            foreach (System.Windows.Forms.Control ctrl in this.Controls)
            {
                ctrl.Enabled = status;
            }
            if (!status)
            {
                button_Cancel.Enabled = true;
            }
        }

        private void MakeRequest(RequestId request) //Method for making requests and Locking SelectionWindow Controls.
        {
            m_Handler.Request.Make(request);
            m_ExEvent.Raise();
            DozeOff();
        }

        private void DozeOff() //method for locking SelectionWindow controls.
        {
            EnableCommands(false);
        }

        public void WakeUp() //method for unlocking SelectionWindow controls.
        {
            EnableCommands(true);
        }

        private void button_Confirm_Click(object sender, EventArgs e) //Method for the Confirm button click Event.
        {
            if (radioButton_SelectAll.Checked)
                MakeRequest(RequestId.All);
            else if (radioButton_UserSelect.Checked)
                MakeRequest(RequestId.UserSelected);
            else
                radioButton_Selected = null;
        }

        private void button_Cancel_Click(object sender, EventArgs e) //Method for the Cancel button click Event.
        {
            this.Close();
        }

        private void button_Select_Click(object sender, EventArgs e) //Method for the Select button click Event.
        {
            userClickedSelectButton = true;
            MakeRequest(RequestId.Selection);
        }

        private void radioButton_UserSelect_CheckedChanged(object sender, EventArgs e) //Method for enabling/disabling the Select button.
        {
            if (radioButton_UserSelect.Checked == true)
                button_Select.Enabled = true;
            else
                button_Select.Enabled = false;
        }
    }
}
