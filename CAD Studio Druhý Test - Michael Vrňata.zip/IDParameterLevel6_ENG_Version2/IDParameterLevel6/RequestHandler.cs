﻿using System;
using System.Collections.Generic;
using System.IO;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;

/// <summary>
/// Class for ExternalEventHandler, that does most of the interactions with Revit.
/// </summary>

namespace IDParameterLevel6
{
    public class RequestHandler : IExternalEventHandler
    {
        bool hasAlteredParameter = false;
        RequestId clickedButton;
        private Request request = new Request();
        static UIApplication uiapp = null;
        static Document doc = null;
        public static List<Element> selectedElements = new List<Element>();
        public static List<Reference> preSelectedElements = new List<Reference>();

        public Request Request
        {
            get { return request; }
        }

        public String GetName() //this method returns the name of the Handler.
        {
            return "CAD Studio Test";
        }
        //Main method of this class
        public void Execute(UIApplication uiapplication)
        {
            uiapp = uiapplication;
            doc = uiapplication.ActiveUIDocument.Document;
            try
            {
                clickedButton = Request.Take();
                switch (clickedButton) //switch that calls on functions, depending on what was clicked in SelectionWindow.
                {
                    case RequestId.None: // Default value of Request.
                        {
                            return;  
                        }
                    case RequestId.All: //User clicked on the Confirm button and radioButton_SelectAll was checked.
                        {
                            GetAllElementsInCanvas();
                            WriteElementID(selectedElements);
                            Application.thisApp.CloseWindow();
                            break;
                            
                        }
                    case RequestId.UserSelected: //User clicked on the Confirm button and radioButton_UserSelect was checked.
                        {
                            if (SelectionWindow.userClickedSelectButton) {
                                if (selectedElements.Count >= 1)
                                    WriteElementID(selectedElements);
                            }
                            else
                            {
                                GetPreSelectedElements();
                                if (selectedElements.Count >= 1)
                                    WriteElementID(selectedElements);
                            }
                            Application.thisApp.CloseWindow();
                            break;
                            
                        }
                    case RequestId.Selection: //User clicked on the Select button.
                        {
                            UserSelection();
                            Application.thisApp.SetFocusOnWindow();
                            break;
                        }
                    default:
                        {
                            break;
                        }
                }
            }
            finally
            {
                Application.thisApp.WakeWindowUp();
            }

            return;
        }

        #region Selecting objects and writing in their ID parameter

        private void WriteElementID(List<Element> elements) //Method for writing ElementID to parameter named ID for selected Objects in Revit.
        {
            foreach (Element e in elements)
            {
                try
                {
                Restart:
                    Parameter para = e.LookupParameter("ID");
                    if (para != null)
                    {
                        using (Transaction t = new Transaction(doc, "Setting the ID parameter"))
                        {
                            t.Start();
                            para.Set(e.Id.ToString());
                            t.Commit();
                            t.Dispose();
                        }
                    }
                    else
                    {
                        if (!hasAlteredParameter)
                        {
                            CheckForIDParameter();
                            goto Restart;
                        }
                    }

                }
                catch (Exception ex)
                {
                    TaskDialog.Show("Error", ex.Message);
                }
            }

            hasAlteredParameter = false;
            preSelectedElements.Clear();
            selectedElements.Clear();
        }
        public void GetAllElementsInCanvas() //Method for retrieving all visible Objects in Revit.
        {
            FilteredElementCollector collector = new FilteredElementCollector(doc).WhereElementIsNotElementType();
            foreach (Element e in collector)
            {
                if (null != e.Category && e.Category.HasMaterialQuantities)
                {
                    selectedElements.Add(e);
                }
            }
        }

        public static void UserSelection() //Method for retrieving Objects, that were selected by User.
        {
            SelectionFilter filter = new SelectionFilter();
            GetPreSelectedElements();
            IList<Reference> elementsSel = uiapp.ActiveUIDocument.Selection.PickObjects(ObjectType.Element, filter, "Select objects", preSelectedElements);
            foreach (Reference r in elementsSel)
            {
                selectedElements.Add(doc.GetElement(r.ElementId));
            }
            SelectionWindow.userClickedSelectButton = false;
        }

        public static void GetPreSelectedElements() //Method for retrieving Objects, that were selected preselected in Revit.
        {
            List<ElementId> selElementID = (List<ElementId>)uiapp.ActiveUIDocument.Selection.GetElementIds();
            Reference r;
            foreach(ElementId eid in selElementID)
            {
                r = new Reference(doc.GetElement(eid));
                preSelectedElements.Add(r);
                if (!SelectionWindow.userClickedSelectButton) //Happens is User hadn´t used the Select button and wants to write the ID of preselected Object only. 
                    selectedElements.Add(doc.GetElement(eid));
            }
        }

        #endregion

        #region Tvorba/úprava parametru ID

        public void CheckForIDParameter() //Method for checking parameter ID.
        {
            try
            {
                bool paraIDExists = false;
                Definition paraDef = null;
                ElementBinding eBinding = null;
                BindingMap map = doc.ParameterBindings;
                DefinitionBindingMapIterator it = map.ForwardIterator();
                it.Reset();
                while (it.MoveNext()) //Check if parameter ID exists.
                {
                    ElementBinding eleBinding = it.Current as ElementBinding;
                    Definition def = it.Key;
                    if (def != null)
                    {
                        if (def.Name == "ID")
                        {
                            paraDef = def;
                            paraIDExists = true;
                            eBinding = eleBinding;
                        }
                    }
                }
                if (!paraIDExists) //Happens if parameter ID does not exist.
                {
                    using (Transaction trans = new Transaction(doc, "Create project parameter ID"))
                    {
                        trans.Start();
                        CategorySet cats;
                        if (clickedButton == RequestId.All)
                        {
                            cats = GetCategorySetFromVisibleElementsInProject();
                        }
                        else
                        {
                            cats = GetCategorySetFromSelectedElementsInProject(eBinding);
                        }
                        RawCreateProjectParameter("ID", ParameterType.Text, true, cats, BuiltInParameterGroup.PG_DATA, true);
                        trans.Commit();
                    }
                }
                else //Happens if parameter ID does exist, but does not have required object category.
                {
                    using (Transaction trans = new Transaction(doc, "Modify project parameter ID"))
                    {
                        trans.Start();
                        CategorySet cats;
                        if (clickedButton == RequestId.All)
                        {
                            cats = GetCategorySetFromVisibleElementsInProject();
                        }
                        else
                        {
                            cats = GetCategorySetFromSelectedElementsInProject(eBinding);
                        }
                        Binding binding = uiapp.Application.Create.NewInstanceBinding(cats);
                        map.ReInsert(paraDef, binding, BuiltInParameterGroup.PG_DATA);
                        trans.Commit();
                    }
                }
                hasAlteredParameter = true;
            }
            catch (Exception ex)
            {
                TaskDialog.Show("Error", ex.Message);
            }
        }

        public static void RawCreateProjectParameter(string name, ParameterType type, bool visible, CategorySet cats, BuiltInParameterGroup group, bool inst) //Method for creating new parameter ID.
        {
            string oriFile = uiapp.Application.SharedParametersFilename;
            string tempFile = Path.GetTempFileName() + ".txt";
            using (File.Create(tempFile)) { }
            uiapp.Application.SharedParametersFilename = tempFile;

            var defOptions = new ExternalDefinitionCreationOptions(name, type)
            {
                Visible = visible
            };
            ExternalDefinition def = uiapp.Application.OpenSharedParameterFile().Groups.Create("TemporaryDefintionGroup").Definitions.Create(defOptions) as ExternalDefinition;

            uiapp.Application.SharedParametersFilename = oriFile;
            File.Delete(tempFile);

            Binding binding = uiapp.Application.Create.NewTypeBinding(cats);
            if (inst) binding = uiapp.Application.Create.NewInstanceBinding(cats);

            BindingMap map = doc.ParameterBindings;
            map.Insert(def, binding, group);

        }

        public CategorySet GetCategorySetFromVisibleElementsInProject() //Gets all categories in project, that can have ID parameter.
        {
            CategorySet catSet = new CategorySet();
            FilteredElementCollector collector = new FilteredElementCollector(doc).WhereElementIsNotElementType();
            foreach (Element e in collector)
            {
                if (null != e.Category && (e.Category.HasMaterialQuantities || e.Category.AllowsBoundParameters))
                {
                    if (!catSet.Contains(e.Category))
                    {
                        catSet.Insert(e.Category);
                    }
                }
            }

            return catSet;
        }

        public CategorySet GetCategorySetFromSelectedElementsInProject(ElementBinding eBinding) //Gets categories of selected objects.
        {
            CategorySet catSet = new CategorySet();
            if (eBinding != null) //If parameter ID does exist, add its categories to categories of selected objects.
            {
                foreach (Category cat in eBinding.Categories)
                {
                    catSet.Insert(cat);
                }
            }

            foreach (Element e in selectedElements)
            {
                if (null != e.Category && (e.Category.HasMaterialQuantities || e.Category.AllowsBoundParameters))
                {
                    if (!catSet.Contains(e.Category))
                    {
                        catSet.Insert(e.Category);
                    }
                }
            }

            return catSet;
        }
        #endregion
    }

}  
